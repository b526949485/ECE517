module WaitlistsHelper
end
