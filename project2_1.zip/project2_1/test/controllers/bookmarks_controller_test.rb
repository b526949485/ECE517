
require 'test_helper'

class BookmarksControllerTest < ActionDispatch::IntegrationTest

end
